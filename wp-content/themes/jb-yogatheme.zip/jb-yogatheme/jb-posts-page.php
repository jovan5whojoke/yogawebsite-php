<?php
/*
 * Template Name: JB-PostsPage
 * Template Post Type: post, page, product
 */
?>

<!DOCTYPE html>
<html>
    <head>
        <title>Yoga - way of life</title>

        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
        <script src="https://code.jquery.com/jquery-1.11.1.min.js"></script>

        <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css">

        <link rel="stylesheet" type="text/css" href="<?php echo get_bloginfo('template_directory'); ?>/resources/css/footer.css">
        <link rel="stylesheet" type="text/css" href="<?php echo get_bloginfo('template_directory'); ?>/resources/css/styles.css">
        <link rel="stylesheet" type="text/css" href="<?php echo get_bloginfo('template_directory'); ?>/resources/css/slider.css">
        <link rel="stylesheet" type="text/css" href="<?php echo get_bloginfo('template_directory'); ?>/resources/css/banner.css">
    </head>
    <body>

        <?php get_template_part( 'navigation' ); ?>

        <section id="jb-posts-section" class="col-xs-12">
            <?php
            //        echo the_modified_date();
            //        echo the_author();
            //        echo the_category();
            //        echo the_ID();
            //        echo get_field('title');
            ?>
            <b>Title</b> -> <?php echo get_field('post_title'); ?> <br><br>
            <b>Description Short</b> -> <?php echo get_field('post_description_short'); ?> <br><br>
            <b>Description Long</b> -> <?php echo get_field('post_description_long'); ?> <br><br>
            <b>Date</b> -> <?php echo the_modified_date(); ?> <br><br>
            <b>Author</b> -> <?php echo the_author(); ?> <br><br>
            <b>Image</b> -> <?php echo get_field('post_image'); ?> <br><br>
            <b>Video</b> -> <?php echo get_field('post_video'); ?> <br><br>

        </section>


        <?php get_footer(); ?>

        <script src="<?php echo get_bloginfo('template_directory'); ?>/resources/js/jb.js"></script>
    </body>
</html>